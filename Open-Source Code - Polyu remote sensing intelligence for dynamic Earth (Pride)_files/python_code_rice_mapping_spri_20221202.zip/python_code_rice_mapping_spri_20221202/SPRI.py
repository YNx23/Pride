#################################################
#######   Code of SPRI for rice mapping  #######
##     The Hong Kong Polytechnic University
##            version: 1 June 2022
##Please contact shuai.xu@connect.polyu.hk 
##               xlzhu@polyu.edu.hk
##        Copyright belongs to Zhu Xiaolin
#################################################

#####################Part 1######################
#######          Data description         #######
#################################################
##1. Sentinel-1 time series (e.g., Testdata_VH.tif)
##2. NDVImax and NDWImax    (e.g., Testdata _NDVImax.tif)
##3. Shapefile of objects   (e.g., Testdata_shapefile.tif)

#####################Part 2######################
#######      Required Python packages     #######
#######       Python version 3.7.10       #######
#################################################
from tkinter import filedialog
import yaml
import numpy as np
import geopandas as gpd
import rasterio
from rasterio.mask import mask
from shapely.geometry import mapping
from osgeo import gdal
import os

#####################Part 3######################
#######         tool functions            #######
#################################################
def read_raster(infile):
    gdal.PushErrorHandler('CPLQuietErrorHandler')
    gdal.UseExceptions()
    fp = gdal.Open(infile)
    cols = fp.RasterXSize
    rows = fp.RasterYSize
    nb = fp.RasterCount
    
    if nb != 1:
        data = np.zeros([rows, cols, nb])
        for i in range(0, nb):
            band = fp.GetRasterBand(i + 1)
            data[:, :, i] = band.ReadAsArray()
            band.GetScale()
            band.GetOffset()
            band.GetNoDataValue()
    else:
        data = fp.ReadAsArray()
        
    return data


def zonal_statistic(shp, raster_file):
    geoms = shp.geometry.values
    zonal = []
    
    for i in range(len(geoms)):
        geom = [mapping(geoms[i])]
        # extract the raster values values within the polygon 
        with rasterio.open(raster_file) as src:
              raster_array, transform = mask(src, geom, crop=True, all_touched=False)
              raster_array = np.ma.masked_array(raster_array, mask=raster_array==0)
        if raster_array.shape[0] != 1:
            zonal.append(np.mean(np.mean(raster_array, axis=1), axis=1))
        else:
            zonal.append(np.mean(raster_array))
 
    if raster_array.shape[0] != 1:
        zonal = np.asarray(np.column_stack([i.squeeze() for i in zonal]))
        return zonal.T
    else:
        return zonal
    
#####################Part 4######################
#######         Index calculation         #######
#################################################

# definte paths using tkinter
sentinel1_file = filedialog.askopenfilename(title=u"Select Sentinel-1 VH time series:")
ndvi_file      = filedialog.askopenfilename(title=u"Select NDVImax file:")
ndwi_file      = filedialog.askopenfilename(title=u"Select NDWImax file:")
shp_file       = filedialog.askopenfilename(title=u"Select shapefile:")
params_file      = filedialog.askopenfilename(title=u"Select parameter settings file:")
# change default directory
os.chdir(os.path.dirname(os.path.dirname(sentinel1_file)))

# or definte paths directly 
# sentinel1_file = r'./Sample data/Testdata_VH.tif'
# ndvi_file      = r'./Sample data/Testdata_NDVImax.tif'
# ndwi_file      = r'./Sample data/Testdata_NDWImax.tif'
# shp_file       = r'./Sample data/Testdata_shapefile.shp'
# params_file    = r'parameters_SPRI.yaml'

# reading data 
sentinel1 = read_raster(sentinel1_file)
ndvi      = read_raster(ndvi_file)
ndwi      = read_raster(ndwi_file)
shp       = gpd.read_file(shp_file)

# reading parameters
params        = yaml.safe_load(open(params_file))
firstdate     = params['firstdate']
is_plain_area = params['is_plain_area']
if is_plain_area == 1:
    w_percentile = 0.1
    v_percentile = 0.1
else:
    w_percentile = 0.90
    v_percentile = 0.25   
    
# zonal statistic
sentinel1_zonal = zonal_statistic(shp, sentinel1_file)
ndvi_zonal      = zonal_statistic(shp, ndvi_file)
ndwi_zonal      = zonal_statistic(shp, ndwi_file)

row_num, col_num = sentinel1_zonal.shape

# Sentinel-1 time series temporal filter
sl_filtered = sentinel1_zonal.copy()
turningPoint = sl_filtered.copy()

for i in range(row_num):
    open_ = 1
    while open_ > 0:
        for j in range(1, col_num):
            turningPoint[i, j] = sl_filtered[i, j-1] - sl_filtered[i, j]
        
        turningPoint[np.isnan(turningPoint)] = 0
        for j in range(col_num):
            if turningPoint[i, j] > 0:
                turningPoint[i, j] = 1
            else:
                turningPoint[i, j] = -1
        
        for j in range(1, col_num-1):
            turningPoint[i, j] = turningPoint[i, j] - turningPoint[i, j+1]
            
        open_ = 0
        for j in range(1, col_num-1):
            if turningPoint[i, j] == -2:
                ex1 = j + 1
                while (turningPoint[i, ex1] != -2) & (ex1 < col_num-1):
                    ex1 += 1
                
                if ((ex1-j) < 4) & ((ex1-j) > 1) & (ex1 < col_num-1) & \
                    (min(sl_filtered[i, j:ex1]) != min(sl_filtered[i, 0:col_num])):
                        for temp in range(j, ex1):
                            sl_filtered[i, temp] = sl_filtered[i, j] + (temp-j) * \
                                (sl_filtered[i, ex1]-sl_filtered[i, j]) / (ex1-j)
                            open_ = 1
        
# Extract local maximum and minimum points (p1, p2)
turningPoint = sentinel1_zonal.copy()
localmaxmin = turningPoint.copy()

# Second order difference method
for i in range(row_num):
    for j in range(1, col_num):
        turningPoint[i, j] = sl_filtered[i, j-1] - sl_filtered[i, j]
        
turningPoint[np.isnan(turningPoint)] = 0

for i in range(row_num):
    for j in range(col_num):
        if turningPoint[i, j] > 0:
            turningPoint[i, j] = 1
        else:
            turningPoint[i, j] = -1
        
for i in range(row_num):
    for j in range(1, col_num-1):
        turningPoint[i, j] = turningPoint[i, j] - turningPoint[i, j+1]

# find all potential local minimum and maximum point
for i in range(row_num):
    for j in range(1, col_num-1):
        if (turningPoint[i, j]==2) & ((turningPoint[i, j-1]==0) | (turningPoint[i, j+1]==0)):
            localmaxmin[i, j] = 2
        elif (turningPoint[i, j]==-2) & (turningPoint[i, j-1]==0) & (turningPoint[i, j+1]==0):
            localmaxmin[i, j] = -2
        else:
            localmaxmin[i, j] = 0
       
# Determine parameter W and V
validation_wv = shp.copy()
validation_wv['NDVImax'] = ndvi_zonal
validation_wv['NDWImax'] = ndwi_zonal
validation_wv['Vline']   = 0
validation_wv['Wline']   = 0
row_num_wv, col_num_wv = validation_wv.shape

for i in range(row_num_wv):
    validation_wv.loc[i, 'Vline'] = np.quantile(sl_filtered[i, :], 0.95)
    validation_wv.loc[i, 'Wline'] = np.quantile(sl_filtered[i, :], 0.05)

ndf1 = validation_wv[validation_wv['NDVImax'] >= 0.4]
ndf2 = validation_wv[(validation_wv['NDVImax'] >= 0.4) & (validation_wv['NDWImax'] >= 0.3)]

try:
    v = np.quantile(ndf1.loc[:, 'Vline'], v_percentile)
    w = np.quantile(ndf2.loc[:, 'Wline'], w_percentile)
except:
    pass

first = 'yes'
if len(ndf1) < 50:
    print('The sample size for V line value is too small!')
    print('The V line value will use the default parameter!')
    if first == 'yes':
        v = -18
    elif first == 'no':
        v = -16
        
if len(ndf2) < 50:
    print('The sample size for W line value is too small!')
    print('The W line value will use the default parameter!')    
    if first == 'yes':
        w = -28
    elif first == 'no':
        w = -22

vw = v - w

# SPRI calculation
def sigmoid(x):
    return 1 / (1 + np.exp(x))
  

for i in range(row_num):
    if (np.mean(sl_filtered[i, :]) > v) | (np.mean(sl_filtered[i, :]) < w):
        localmaxmin[i, :] = 0
    for j in range(col_num):
        if localmaxmin[i, j] == 2:
            p1 = max(sl_filtered[i, j], w)
            m  = min(j+1, col_num)
            while (localmaxmin[i, m] != 2) & (m < col_num-1):
                m += 1
            p2  = min(max(sl_filtered[i, j:m]), v)
            p1j = np.argmax(sl_filtered[i, j:m]) + j -1
            n   = min(m, col_num)
            while (localmaxmin[i, n] != -2) & (n < col_num-1):
                n += 1
            if (sl_filtered[i, j] < sl_filtered[i, m]) & ((n-j) < 14) & (n != col_num)\
                & (max(sl_filtered[i, j:m]) < sl_filtered[i, n]):
                    p2  = min(sl_filtered[i, n], v)
                    p1j = m
            detmp = (p2 - p1) / vw
            d     = max(detmp, 0)
            spd   = vw * (1 - d) - vw / 2
            sig   = sigmoid(spd)
            wp    = np.abs(p1 - w) / vw
            vp    = np.abs(p2 - v) / vw
            
            localmaxmin[i, j] = sig * (1-wp**2) * (1-vp**2)
        else:
            localmaxmin[i, j] = 0
      
result_output = shp.copy()
result_output['Rice_prob'] = 0    
result_output['Date'] = 0 

for i in range(row_num):
    result_output.loc[i, 'Rice_prob'] = max(localmaxmin[i, 0:col_num])
    result_output.loc[i, 'Date'] = np.argmax(localmaxmin[i, 0:col_num]-1) * 12 + firstdate
    
# Output SPRI result
result_output.to_file(r'./Result/Result_output.shp')