library(svDialogs)


first=tcltk::tk_messageBox(caption = "The first question", 
message = "Does your study area locate at the plain area?
YES: Plain area 
No: Mountainous areas and hills", icon = "info", type = "yesno")


if (first=="yes"){
W_percentile = 0.1    # Percentile of candidate values for W line
V_percentile = 0.1    # Percentile of candidate values for V line
}
if (first=="no"){
W_percentile = 0.9   # Percentile of candidate values for W line
V_percentile = 0.25   # Percentile of candidate values for V line
}

## Date of year of the first image in Sentinel-1 time series 
Firstdate <- as.numeric(dlgInput("Please type DOY of the first image in Sentinel-1 (e.g.,5)")$res)
