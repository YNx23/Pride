function [ coe ] = regressperpixel_mean( data1 )

coe=double(zeros(1,3));
nodata=-9999;
[nrows_N,ncols_N]=size(data1);

datar=double(zeros(1,2));
rad=4;%regress window size-7*7
m=1;

%Search for the PLPs and calculate the weighted sum of their neighbour
%lighter pixels
for i=rad:(nrows_N-(rad-1))
   for j=rad:(ncols_N-(rad-1))
       if data1(i,j)~=nodata & data1(i,j)~=0
	   s=0;
	   d=0;

	  for ii=(i-1):(i+1)
	     for jj=(j-1):(j+1)
		    
              if data1(ii,jj)==0
			     s=1;
			  end
		  end
		end
		

		if s==1
		for ii=(i-(rad-1)):(i+(rad-1))
	     for jj=(j-(rad-1)):(j+(rad-1))

			if data1(ii,jj)>data1(i,j)  & (ii~=i | jj~=j) 
		    d=d+(data1(ii,jj))/(((i-ii)^2+(j-jj)^2));
			
			end
			end
		end
		if d~=0
		datar(m,1)=data1(i,j);
		datar(m,2)=d;
		m=m+1;
		end
		end
		end
	end
end
[aa id1 id2]=unique(datar(:,1));
len=max(id2);
data_final=[aa zeros(len,1)];
for i=1:len
    idx=find(id2==i);
    data_final(i,2)=mean(datar(idx,2));
end	

if len>=10
X=[ones(len,1), data_final(:,2)] ;
[B,BINT,R,RINT,STATS] = regress(data_final(:,1),X);
coe(1,1)=B(2,1);
coe(1,2)=B(1,1);
coe(1,3)=STATS(1,1);
end

end

