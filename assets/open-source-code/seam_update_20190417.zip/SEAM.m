%---------------------------------------------------------------------------------
%                            SEAM PROGRAM

%        Developed by (1) Yang Hu,email: HuYangIvy0724@126.com
%              Faculty of Geographical Science
%                  Beijing Normal University
            
%Please cite the reference: Xin Cao, Yang Hu, Xiaolin Zhu, Feng Shi, Li Zhuo, Jin Chen.
%A simple self-adjusting model for correcting the blooming effects in DMSP-OLS nighttime light images. 
%Remote Sensing of Environment, 2019, 224, 401-411.
%                     Copyright belongs to Yang Hu
%---------------------------------------------------------------------------------
clear
%data input
[data2,header,ncols_N,nrows_N,xll_N,yll_N,cellsize_N,nodata]=imreadasc('E:\Code for SEAM\Test data\beijing_DMSP.asc');

%3*3mean filter
rad=2;
data1=double(zeros(nrows_N,ncols_N));
for i=rad:(nrows_N-(rad-1))
   for j=rad:(ncols_N-(rad-1))
     if data2(i,j)~=nodata & data2(i,j)~=0
	   s=0;
	   for ii=(i-(rad-1)):(i+(rad-1))
	     for jj=(j-(rad-1)):(j+(rad-1))
             if data2(ii,jj)~=nodata
		         s=s+data2(ii,jj);
             end
		 end
		 end
		 data1(i,j)=s/9.0;
		 else
		 data1(i,j)=data2(i,j);
		 end
		 end
end

%regression coefficients calculation
a=double(zeros(nrows_N,ncols_N));
b=double(zeros(nrows_N,ncols_N));
rq=double(zeros(nrows_N,ncols_N));

for i=(rad):(nrows_N-(rad-1))
   for j=(rad):(ncols_N-(rad-1))
       if data1(i,j)~=nodata & data1(i,j)~=0
           delta=0;
           coe=double(zeros(1,3));       
           maxrq=0;          
           r=150;
           ir=max((i-r),2);
           ri=min((i+r),(nrows_N-1));
           jr=max((j-r),2);
           rj=min((j+r),(ncols_N-1));
           data=data1(ir:ri,jr:rj);
           coe=regressperpixel_mean(data);     
               a(i,j)=coe(1,1);
               b(i,j)=coe(1,2);
               rq(i,j)=coe(1,3);
                  
       end
   end
end

%regression coefficients adjustment
for i=rad:(nrows_N-(rad-1))
   for j=rad:(ncols_N-(rad-1))
     if (rq(i,j)<0.5 & data1(i,j)>0)
          
             r=0;
             
             while rq(i,j)<0.5                 
             r=r+1;
             ir=max((i-r),2);
             ri=min((i+r),(nrows_N-1));
             jr=max((j-r),2);
             rj=min((j+r),(ncols_N-1));
             d=1000000;
             for ii=ir:ri
                 for jj=jr:rj
                     if rq(ii,jj)>0.5 & (ii~=i | jj~=j)
                         dd=(ii-i)^2+(jj-j)^2;
                         if dd<d
                             a(i,j)=a(ii,jj);
                             b(i,j)=b(ii,jj);
                             rq(i,j)=rq(ii,jj);
                             d=dd;
                           
                         end
                     end
                 end
             end
         end
         
     end
   end
end

for i=rad:(nrows_N-(rad-1))
   for j=rad:(ncols_N-(rad-1))
     if a(i,j)<0 
          
             r=0;
             while a(i,j)<0
                 
             r=r+1;
             ir=max((i-r),2);
             ri=min((i+r),(nrows_N-1));
             jr=max((j-r),2);
             rj=min((j+r),(ncols_N-1));
             d=1000000;
             for ii=ir:ri
                 for jj=jr:rj
                     if a(ii,jj)>0 & (ii~=i | jj~=j)
                         dd=(ii-i)^2+(jj-j)^2;
                         if dd<d
                             a(i,j)=a(ii,jj);
                             b(i,j)=b(ii,jj);
                             rq(i,j)=rq(ii,jj);
                             d=dd;
                           
                         end
                     end
                 end
             end
         end
         
     end
   end
end

%excluding blooming effect
 rad=4;
 data_result=double(zeros(nrows_N,ncols_N));
 for i=rad:(nrows_N-(rad-1))
   for j=rad:(ncols_N-(rad-1))
       if data1(i,j)>0
	   s=0;
	   d=0;
	   s1=0;
	   s2=0;

         for ii=(i-(rad-1)):(i+(rad-1))
	          for jj=(j-(rad-1)):(j+(rad-1))
		          if data1(ii,jj)>data1(i,j)  & (ii~=i | jj~=j) 
				    s1=s1+(data1(ii,jj))/(((i-ii)^2+(j-jj)^2));
                  end				
			  end
		end

		
			 if s1~=0
			 pv=data1(i,j)-a(i,j)*s1-b(i,j);
			 if pv<0
			 data_result(i,j)=0;
			 else
			 data_result(i,j)=pv;
			end
		else
		    data_result(i,j)=data1(i,j);
			end
		
	
		
	else
	   data_result(i,j)=data1(i,j);
	   
	end
	end
end

data_result(:,1:(rad-1))=data1(:,1:(rad-1));
data_result(:,(ncols_N-(rad-2)):ncols_N)=data1(:,(ncols_N-(rad-2)):ncols_N);
data_result(1:(rad-1),:)=data1(1:(rad-1),:);
data_result((nrows_N-(rad-2)):nrows_N,:)=data1((nrows_N-(rad-2)):nrows_N,:);

%data output
imwriteasc2('E:\Code for SEAM\Test data\result.asc',data_result,xll_N,yll_N,nrows_N,ncols_N,cellsize_N,nodata); 
