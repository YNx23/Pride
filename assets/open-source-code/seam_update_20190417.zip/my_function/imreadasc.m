% read asc grid data
% function [A,header,ncols,nrows,xllcorner,yllcorner,cellsize,nodata]=imreadasc(filename)

function [A,header,ncols,nrows,xllcorner,yllcorner,cellsize,nodata]=imreadasc(filename)
   format long g;
   fid=fopen(filename,'r'); 
   %get file header information
   line=fgetl(fid);
   header{1,1}=line;
   ncols=sscanf(line, '%*s %g', [1, inf]);
   line=fgetl(fid);
   header{2,1}=line;
   nrows=sscanf(line, '%*s %g', [1, inf]);
   line=fgetl(fid);
   header{3,1}=line;
   xllcorner=sscanf(line, '%*s %g', [1, inf]);
   line=fgetl(fid);
   header{4,1}=line;
   yllcorner=sscanf(line, '%*s %g', [1, inf]);
   line=fgetl(fid);
   header{5,1}=line;
   cellsize=sscanf(line, '%*s %g', [1, inf]);
   line=fgetl(fid);
   header{6,1}=line;
   nodata=sscanf(line, '%*s %g', [1, inf]);
   clear line;
   
   %read grid data
   A = fscanf(fid, '%g', [ncols nrows]);
   A=A';
 
   fclose(fid);
   clear fid;
end