% usage: imwriteasc2(output,data,xllcorner,yllcorner,nrows,ncols,cellsize,NODATA_value)
function imwriteasc2(output,data,xllcorner,yllcorner,nrows,ncols,cellsize,NODATA_value,ori)
	if exist('ori')==0 | isempty(ori)==1	
		ori=0;
	end

	if exist('NODATA_value')==0 | isempty(NODATA_value)==1	
		NODATA_value=-9999;
	end
	
	header={};
	header{1,1}=['ncols         ',num2str(ncols)];
	header{2,1}=['nrows         ',num2str(nrows)];
	header{3,1}=['xllcorner     ',num2str(xllcorner)];
	header{4,1}=['yllcorner     ',num2str(yllcorner)];
	header{5,1}=['cellsize      ',num2str(cellsize)];
	header{6,1}=['NODATA_value  ',num2str(NODATA_value)];
	
	if ori==0										% top-left
		imwriteasc(output,header,data);
	elseif ori==1									% bottom-left
		imwriteasc(output,header,flipud(data));
	end	

end

