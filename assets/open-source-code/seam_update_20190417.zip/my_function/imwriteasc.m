%write *.asc file
%function imwriteasc(filename, header, data)
function imwriteasc(filename, header, data)
   %create new asc file
   fid=fopen(filename,'w');
   %write header information
   for i=1:6
      fprintf(fid, '%s\n', header{i,1});
   end
   fclose(fid);
   clear fid;
   % write data
   format long g;
   dlmwrite(filename, data, '-append','delimiter', ' ', 'precision', '%.8f');
end
