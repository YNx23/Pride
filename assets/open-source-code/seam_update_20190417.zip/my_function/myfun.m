% help informatiom
% usage: [output1, output2] = myfun(input1, input2)
% usage: output1 = myfun(input1, input2)

function [output1, output2]=myfun(input1, input2)
	output1 = input1 + input2;
	output2 = (input1 + input2) / 2;
end