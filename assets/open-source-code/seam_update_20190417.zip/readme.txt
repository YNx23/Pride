SEAM.m: the main program

regressperpixel_mean.m: a subprogram called by "SEAM.m"

input data: default format is ASCII. User can change it to other format in the code

If you meet any problem or have any questions, please contact Miss Hu Yang (email: HuYangIvy0724@126.com)