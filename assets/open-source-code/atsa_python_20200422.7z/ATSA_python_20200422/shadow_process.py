from sklearn.cluster import KMeans
import numpy as np
import simple_idw

def classify_shadow(type, type_shadow_p, shadow_new, mask_shadow_ini, water, n_image):
    """
    use K-means clustering to classify shadow pixels into 2 classes
    Args:
        type: 'land' or 'water'
        type_shadow_p: land surface or water surface in shadow mask
        shadow_new: HOT used for selecting samples
        mask_shadow_ini: initial shadow mask
        water: the input water mask
        n_image: the number of input images
    return:
        center_class: HOT centers of clear, thin and thick cloudy pixels on land or water
        mask_shadow_ini: the computed shadow mask with value 0: shadow 1: clear pixels 2: clouds 3:background or missing pixels
    """

    num_cluster = 2
    n_sample_kmean = 10000.0
    num_type_shadow = np.size(type_shadow_p) / len(type_shadow_p)
    if num_type_shadow > 100:
        n_sample_kmean = min([n_sample_kmean, num_type_shadow])
        inter_sample = np.floor(num_type_shadow/n_sample_kmean)
        index_sample = (np.arange(n_sample_kmean)).astype(int)*int(inter_sample)  # find the location of the samples??
        sample_shadow = np.zeros((int(n_sample_kmean), 1)).astype(float)
        sample_shadow[:, 0] = shadow_new[tuple(type_shadow_p[:, index_sample])]

        # use k-means to classify shadow samples into two classes

        center_class = KMeans(n_clusters=num_cluster, n_init=50, random_state=0).fit(sample_shadow)
        center_class = np.sort((center_class.cluster_centers_).ravel())
        print('centers of shadow and nonshadow pixels on', type, ':', center_class)

        # classify each shadow image by k-means centers
        for ib in range(0, n_image):
            if type == 'land':
                ind_type_ib = np.logical_and(shadow_new[ib, :, :] < 0, water == 1)
            elif type == 'water':
                ind_type_ib = np.logical_and(shadow_new[ib, :, :] != 0, water == 0)

            shadow_i = (shadow_new[ib, :, :])[ind_type_ib]
            dis_c1 = abs(shadow_i - center_class[0])
            dis_c2 = abs(shadow_i - center_class[1])
            temp = mask_shadow_ini[ib, :, :].copy()
            temp[ind_type_ib] = ((dis_c1 >= dis_c2).astype(int))
            mask_shadow_ini[ib, :, :] = temp

        return center_class[0], center_class[1], mask_shadow_ini

def remove_shadow(mask, ns, nl, n_image):
    """
    remove isolated shadow pixels
    Args:
        mask: the updated mask
        ns: the columns
        nl: the rows
        n_image: the number of input images
    return:
        mask: the updated mask after removing isolated shadow pixels
    """

    for ii in range(0, n_image):
        diff = 1000
        itime = 0
        while diff >= 5 >= itime:
            mask0 = mask[ii, :, :].copy()
            for i in range(0, ns):
                for j in range(0, nl):
                    # moving window
                    if mask[ii, j, i] == 0:
                        a1 = max([i - 1, 0])
                        a2 = min([ns - 1, i + 1])
                        b1 = max([0, j - 1])
                        b2 = min([nl - 1, j + 1])
                        mask_win = mask0[b1:b2 + 1, a1:a2 + 1].copy()
                        ind_c = mask_win == 0
                        num_c = np.sum(ind_c)
                        if num_c <= 3:
                            mask[ii, j, i] = 1  # remove isolate cloud pixels

            diff = np.sum(abs(mask[ii, :, :] - mask0))
            itime = itime + 1

    return mask


def buffer_shadow(mask2, buffern, type, value, ns, nl, n_image):
    """
    buffer all shadow pixels to further reduce omission errors around edges
    Args:
        mask2: the updated mask
        buffern: the buffer size
        type: 'buffer1': buffer the possible shadow
              'buffer2': buffer the shadow zone to predict potential zone from IDW
              'buffer3': buffer shadow to acquire the cloud and shadow mask
        value: the value to update mask2
        ns: the columns
        nl: the rows
        n_image: the number of input images
    return:
        mask0: the updated shadow mask
    """

    mask0 = mask2.copy()
    for ii in range(0, n_image):
        for i in range(0, ns):
            for j in range(0, nl):

                # get the buffer zone
                if mask2[ii, j, i] == 0:
                    a1 = max([i-buffern, 0])
                    a2 = min([ns-1, i+buffern])
                    b1 = max([0, j-buffern])
                    b2 = min([nl-1, j+buffern])
                    if type == 'buffer1':
                        ind_nonback = mask2[ii, b1:b2+1, a1:a2+1] == 1
                        num_cad = np.sum(ind_nonback)
                        if num_cad > 0:
                            temp = mask2[ii, b1:b2+1, a1:a2+1].copy()
                            temp[ind_nonback] = value
                            mask0[ii, b1:b2+1, a1:a2+1] = temp

                    if type == 'buffer2':
                        ind_nonback = np.logical_or(mask2[ii, b1:b2+1, a1:a2+1] == 1, mask2[ii, b1:b2+1, a1:a2+1] == 99)
                        num_cad = np.sum(ind_nonback)
                        if num_cad > 0:
                            temp = mask2[ii, b1:b2+1, a1:a2+1].copy()
                            temp[ind_nonback] = value
                            mask0[ii, b1:b2+1, a1:a2+1] = temp

                    if type == 'buffer3':
                        ind_nonback = np.logical_and(mask2[ii, b1:b2+1, a1:a2+1] != 3, mask2[ii, b1:b2+1, a1:a2+1] != 2)
                        temp = mask0[ii, b1:b2 + 1, a1:a2 + 1].copy()
                        temp[ind_nonback] = value
                        mask0[ii, b1:b2 + 1, a1:a2 + 1] = temp

    return mask0

def potential_shadow(type_, shadow_buffer, mask2, shadow, shadow_new, shadowbase, ii, water, col_ind, row_ind):
    '''
    Predict the potential shadow zones from surrounding clear pixels with an IDW interpolator and estimate their
    darkness as original shadow index minus the predicted values used for K-means clustering
    '''
    if type_ == 'land':
        ind_good = np.logical_and(water == 1, shadow_buffer[ii, :, :] == 10)
        ind_shadow = np.logical_and(water == 1, mask2[ii, :, :] == 0)
    if type_ == 'water':
        ind_good = np.logical_and(water == 0, shadow_buffer[ii, :, :] == 10)
        ind_shadow = np.logical_and(water == 0, mask2[ii, :, :] == 0)

    num_good = np.sum(ind_good)
    num_shadow = np.sum(ind_shadow)

    if num_good > 100 and num_shadow > 0:
        # if the image has both good pixels and potential shadow pixels
        shadow_good = (shadow[ii, :, :])[ind_good]
        col_ind_good = col_ind[ind_good]
        row_ind_good = row_ind[ind_good]
        col_ind_shadow = col_ind[ind_shadow]
        row_ind_shadow = row_ind[ind_shadow]

        # spatial interpolation by inverse distance weighted
        grid = simple_idw.simple_idw(row_ind_good, col_ind_good, shadow_good, row_ind_shadow, col_ind_shadow)

        temp = shadow_new[ii, :, :]
        temp[ind_shadow] = (shadow[ii, :, :])[ind_shadow]-grid
        shadow_new[ii, :, :] = temp
    else:
        if (type_ == 'land' and num_shadow > 0) or (type_ == 'water' and num_shadow > 0 and num_good <= 100):
            temp = shadow_new[ii, :, :]
            temp[ind_shadow] = (shadow[ii, :, :])[ind_shadow]-shadowbase[ind_shadow]
            shadow_new[ii, :, :] = temp

    return shadow_new


