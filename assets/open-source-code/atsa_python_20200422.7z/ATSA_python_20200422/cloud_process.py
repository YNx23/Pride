from sklearn.cluster import KMeans
import numpy as np


def classify_cloud(type, type_cloud_p, HOT, mask, water, n_image):
    """
    use K-means clustering to classify cloud pixels into 3 classes
    Args:
        type: 'land' or 'water'
        type_cloud_p: land surface or water surface in cloud mask
        HOT: HOT used for selecting samples
        mask: initial cloud mask
        water: the input water mask
        n_image: the number of input images
    return:
        center_class: HOT centers of clear, thin and thick cloudy pixels on land or water
        mask: the computed cloud mask with value 0: shadow 1: clear pixels 2: clouds 3: background or missing pixels
    """
    num_cluster = 3
    n_sample_kmean = 10000.0
    num_type_cloud = np.size(type_cloud_p) / len(type_cloud_p)
    if num_type_cloud > 100:
        n_sample_kmean = min([n_sample_kmean, num_type_cloud])
        inter_sample = np.floor(num_type_cloud/n_sample_kmean)
        index_sample = (np.arange(n_sample_kmean)).astype(int)*int(inter_sample)  # find the location of the samples??
        sample_cloud = np.zeros((int(n_sample_kmean), 1)).astype(float)
        sample_cloud[:, 0] = HOT[tuple(type_cloud_p[:, index_sample])]

        center_class = KMeans(n_clusters=num_cluster, n_init=50, random_state=0).fit(sample_cloud)
        center_class = np.sort((center_class.cluster_centers_).ravel())
        print("HOT centers of clear, thin and thick cloudy pixels on", type, ':', center_class)

        # classify each image by k-means centers
        for ib in range(0, n_image):
            if type == 'land':
                ind_type_ib = np.logical_and(mask[ib, :, :] != 3, water == 1)
            elif type == 'water':
                ind_type_ib = np.logical_and(mask[ib, :, :] != 3, water == 0)

            cloud_i = (HOT[ib, :, :])[ind_type_ib]
            dis_c1 = abs(cloud_i - center_class[0])
            dis_c2 = abs(cloud_i - center_class[1])
            temp = mask[ib, :, :].copy()
            temp[ind_type_ib] = ((dis_c1 >= dis_c2).astype(int)) + 1
            mask[ib, :, :] = temp

        return center_class[0], center_class[1], mask

def remove_cloud(times, mask, ns, nl, n_image):
    """
    remove isolated cloud pixels
    Args:
        times: 1:remove isolate cloud pixels in initial cloud mask  2: remove isolate cloud pixels by an iterative process
        mask: the updated mask
        ns: the columns
        nl: the rows
        n_image: the number of input images
    return:
        mask: the updated mask after removing isolated cloud pixels
    """

    if times == 1:

        for ii in range(0, n_image):
            mask0 = mask[ii, :, :].copy()
            for i in range(0, ns):
                for j in range(0, nl):
                    # moving window
                    if mask[ii, j, i] == 2:
                        a1 = max([i-2, 0])
                        a2 = min([ns-1, i+2])
                        b1 = max([0, j-2])
                        b2 = min([nl-1, j+2])
                        mask_win = mask0[b1:b2+1, a1:a2+1].copy()
                        ind_c = mask_win == 2
                        num_c = np.sum(ind_c)
                        if num_c <= 7:
                            mask[ii, j, i] = 1  # remove isolate cloud pixels

    if times == 2:

        for ii in range(0, n_image):
            diff = 1000
            itime = 0
            while diff >= 5 >= itime:
                mask0 = mask[ii, :, :].copy()
                for i in range(0, ns):
                    for j in range(0, nl):
                        # moving window
                        if mask[ii, j, i] == 2:
                            a1 = max([i-2, 0])
                            a2 = min([ns-1, i+2])
                            b1 = max([0, j-2])
                            b2 = min([nl-1, j+2])
                            mask_win = mask0[b1:b2+1, a1:a2+1].copy()
                            ind_c = mask_win == 2
                            num_c = np.sum(ind_c)
                            if num_c <= 7:
                                mask[ii, j, i] = 1  # remove isolate cloud pixels

                diff = np.sum(abs(mask[ii, :, :] - mask0))
                itime = itime + 1

    return mask

def buffer_cloud(mask, buffern, ns, nl, n_image):
    """
    buffer all could pixels to further reduce omission errors around edges
    Args:
        mask: the computed mask from last step
        buffern: the buffer size of cloud patches
        ns: the columns
        nl: the rows
        n_image: the number of input images
    return:
        cloud: the updated cloud mask
    """

    cloud = mask.copy()
    for j in range(0, nl):
        for i in range(0, ns):
            for ii in range(0, n_image):

                # get the buffer zone
                if mask[ii, j, i] == 2:
                    a1 = max([i-buffern, 0])
                    a2 = min([ns-1, i+buffern])
                    b1 = max([0, j-buffern])
                    b2 = min([nl-1, j+buffern])
                    ind_nonback = np.where(mask[ii, b1:b2+1, a1:a2+1] != 3)
                    temp = cloud[ii, b1:b2+1, a1:a2+1].copy()
                    temp[ind_nonback] = 2
                    cloud[ii, b1:b2+1, a1:a2+1] = temp

    return cloud