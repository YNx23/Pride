import numpy as np
import gdal

def read_raster(infile):
    gdal.PushErrorHandler('CPLQuietErrorHandler')
    gdal.UseExceptions()
    fp = gdal.Open(infile)
    cols = fp.RasterXSize
    rows = fp.RasterYSize
    nb = fp.RasterCount
    data = np.zeros([nb, rows, cols])
    for i in range(0, nb):
        band = fp.GetRasterBand(i+1)
        data[i, :, :] = band.ReadAsArray()
        band.GetScale()
        band.GetOffset()
        band.GetNoDataValue()
    return rows, cols, data

def saveimage(dataset, filename_out, filename_in, type_):

    [nb, rows, cols] = dataset.shape
    outform = str(filename_out)
    format = "GTiff"
    driver = gdal.GetDriverByName(format)
    gdal.AllRegister()
    if type_ == 'float':
        outDataset = driver.Create(outform, cols, rows, nb, gdal.GDT_Float32)
    elif type_ == 'int':
        outDataset = driver.Create(outform, cols, rows, nb, gdal.GDT_Int16)
    elif type_ == 'byte':
        outDataset = driver.Create(outform, cols, rows, nb, gdal.GDT_Byte)
    for i in range(nb):
        outDataset.GetRasterBand(i + 1).WriteArray(dataset[i, :, :], 0, 0)
    geoTransform = filename_in.GetGeoTransform()
    outDataset.SetGeoTransform(geoTransform)
    proj = filename_in.GetProjection()
    outDataset.SetProjection(proj)
