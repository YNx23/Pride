import datetime
from tkinter import filedialog
from utils_buffer import read_raster, writeimage
import gdal
import numpy as np
import os

# set the following parameters
buffer_zone = 2    # width of buffer

starttime = datetime.datetime.now()  # initial time

# open final cloud mask time-series
path1 = filedialog.askopenfilename(title=u"open ATSA mask images:")  # shadow 0, clear 1, cloud 2, gap/background 3
nl, ns, mask = read_raster(path1)
fp = gdal.Open(path1)
nb = fp.RasterCount
mask2 = mask.copy()

# recode the pixel values for running missing pixel repairing code: NSPI_TIMESERIES.pro , clear 0, gap/background 1 shadow 2 cloud 3 buffer 4
for ib in range(0, nb):
    ind0 = np.where(mask[ib, :, :] == 0)
    num_0 = int(int(np.size(ind0)) / len(ind0))
    if num_0 > 0:
        temp = mask2[ib, :, :]
        temp[ind0] = 2
        mask2[ib, :, :] = temp

    ind1 = np.where(mask[ib, :, :] == 1)
    num_1 = int(np.size(ind1)) / len(ind1)
    if num_1 > 1:
        temp = mask2[ib, :, :]
        temp[ind1] = 0
        mask2[ib, :, :] = temp

    ind2 = np.where(mask[ib, :, :] == 2)
    num_2 = int(np.size(ind2)) / len(ind2)
    if num_2 > 0:
        temp = mask2[ib, :, :]
        temp[ind2] = 3
        mask2[ib, :, :] = temp

    ind3 = np.where(mask[ib, :, :] == 3)
    num_3 = int(np.size(ind3)) / len(ind3)
    if num_3 > 0:
        temp = mask2[ib, :, :]
        temp[ind3] = 1
        mask2[ib, :, :] = temp

# get buffer
mask_b = mask2
for i in range(0, ns):
    for j in range(0, nl):
        for ii in range(0, nb):

            # get the buffer zone
            if mask2[ii, j, i] == 3 or mask2[ii, j, i] == 2:
                a1 = np.max([0, i - buffer_zone])
                a2 = np.min([ns - 1, i + buffer_zone])
                b1 = np.max([0, j - buffer_zone])
                b2 = np.min([nl - 1, j + buffer_zone])
                mask_win = mask2[ii, b1:b2+1, a1:a2+1]
                ind_c = np.where(mask_win == 0)
                num_c = int(np.size(ind_c)) / len(ind_c)
                if num_c > 0:
                    temp = mask_b[ii, b1:b2+1, a1:a2+1]
                    temp[ind_c] = 4
                    mask_b[ii, b1:b2+1, a1:a2+1] = temp

# output the results
suffix = os.path.splitext(path1)[-1]
Filename = os.path.splitext(path1)[0] + '_recoded_buffered' + suffix
fp = path1
writeimage(mask_b, Filename, fp, 'int8')

endtime = datetime.datetime.now()
print('Time used: ', (endtime - starttime).seconds, 'seconds')















