# -*- coding: utf-8 -*-
"""
Created on Wed Sep 11 11:43:29 2019
ATSA method for masking cloud, shadow in Landsat time-series images or similar multi-spectral time-series data
------------------------------------------------------------------------------------------------------------------------
                              * Automatic Time-Series Analysis (ATSA) Method*
------------------------------------------------------------------------------------------------------------------------
Reference: Zhu,X.,and Helmer,E.H. An automatic method for screening clouds and cloud shadows in optical satellite image
time series in cloudy regions, Remote Sensing of Environment, Volume 214, 2018, Pages 135-153

@author: Administrator
"""

import HOT as hot
import os
import yaml
import gdal
import numpy as np
import math
from utils import saveimage, read_raster
import datetime
from cloud_process import classify_cloud, remove_cloud, buffer_cloud
from shadow_process import classify_shadow, remove_shadow, buffer_shadow, potential_shadow
import tkinter as tk
from tkinter import filedialog

# *******************************Set parameters and read input data*************************************
# ******************************************************************************************************

root = tk.Tk()
root.withdraw()

# Please set the appropriate parameters for your own data in parameters.yaml before open this file!
f = open(filedialog.askopenfilename(title=u"open the parameter settings file:"))
param = yaml.safe_load(f)

dn_max = param['dn_max']  # maximum value of DN, e.g. 7-bit data is 127, 8-bit is 255
background = param['background']  # DN value of background or missing values, such as SLC-off gaps
buffer = param['buffer']  # width of buffer applied to detected cloud and shadow, recommend 1 or 2

# parameters for HOT calculation and cloud detection
n_image = param['n_image']  # number of images in the time-series
n_band = param['n_band']  # number of bands of each image
blue_b = param['blue_b']  # band index of blue band, note: MSS does not have blue, use green as blue
green_b = param['green_b']  # band index of green band
red_b = param['red_b']  # band index of red band
nir_b = param['nir_b']  # band index of nir band
swir_b = param['swir_b']  # band index of swir band
A_cloud = param['A_cloud']  # threshold to identify cloud (mean+A_cloud*sd), recommend 0.5-1.5, smaller values can detect thinner clouds
maxblue_clearland = dn_max * 0.15  # estimated maximum blue band value for clear land surface
maxnir_clearwater = dn_max * 0.05  # estimated maximum nir band value for clear water surface

# parameters for shadow detection
shortest_d = param['shortest_d']  # shortest distance between shadow and cloud, unit is pixel resolution
longest_d = param['longest_d']  # longest distance between shadow and its corresponding cloud, unit is "pixel",can be set empirically by inspecting images
B_shadow = param['B_shadow']   # threshold to identify shadow (mean-B_shadow*sd), recommend 1-3, smaller values can detect lighter shadows

# set the folder for storing output results
tempfile = filedialog.askdirectory(title=u"set the output folder")

# read data
path1 = filedialog.askopenfilename(title=u"open time-series images:")
nl, ns, data = read_raster(path1)

# read water mask
path2 = filedialog.askopenfilename(title=u"open water mask data (water is with 0 value):")
_, _, water = read_raster(path2)
water = water.reshape(nl, ns)

# read sun angle
path3 = filedialog.askopenfilename(title=u"open sun angle txt file:")
sun = np.loadtxt(path3)

sun[:, 0] = 90 - sun[:, 0]
starttime = datetime.datetime.now()  # initial time

# column and row index
row_ind = np.zeros((nl, ns)).astype(int)
col_ind = np.zeros((nl, ns)).astype(int)
for i in range(0, ns):
    col_ind[:, i] = i
for i in range(0, nl):
    row_ind[i, :] = i

# ******************************** Calculate HOT as Cloud Index********************************
# *********************************************************************************************

mask = np.ones((n_image, nl, ns)).astype(int)
HOT = np.zeros((n_image, nl, ns)).astype(float)
rmin0 = 0.01 * dn_max  # min DN value of blue band for computing clear line
rmax = maxblue_clearland  # max DN value of blue band for computing clear line
n_bin = 50  # number of bins between rmin and rmax

HOT_slop_land = np.zeros(n_image).astype(float)
HOT_int_land = np.zeros(n_image).astype(float)
# for land surface
for ii in range(0, n_image):
    ind_l = np.logical_and(np.logical_or(water == 1, data[n_band * ii + nir_b - 1, :, :] >= dn_max * 0.1),
                           data[n_band * ii + nir_b - 1, :, :] != background)

    num_l = np.sum(ind_l)
    if num_l > 0:
        data_blue = (data[n_band * ii + blue_b - 1, :, :])[ind_l]
        ind_valid = np.logical_and(data_blue >= rmin0, data_blue <= rmax)
        num_valid = np.sum(ind_valid)
        if num_valid > 500:
            data_red = (data[n_band * ii + red_b - 1, :, :])[ind_l]
            temp = HOT[ii, :, :].copy()
            rmin = min(data_blue[ind_valid])
            Compute_HOT = hot.Compute_hot(data_blue, data_red, rmin, rmax, n_bin)
            temp[ind_l] = Compute_HOT[0]
            HOT[ii, :, :] = temp
            HOT_slop_land[ii] = Compute_HOT[1]
            HOT_int_land[ii] = Compute_HOT[2]

# find images totally covered by clouds or unreasonable clear-sky line
ind_t = np.where(HOT_slop_land == 0)
ind_t = np.array(ind_t)
num_t = int(np.size(ind_t) / len(ind_t))
if num_t < n_image:
    mean_slop = np.mean(HOT_slop_land[(HOT_slop_land != 0)])
    mean_int = np.mean(HOT_int_land[(HOT_int_land != 0)])
else:
    mean_slop = 1.5  # for extreme case: no image can get valid clear_sky line
    mean_int = 0

if num_t > 0:  # use average slope for those totally covered images
    for it in range(0, num_t):
        data_blue = data[n_band * ind_t[0, it] + blue_b - 1, :, :]
        data_red = data[n_band * ind_t[0, it] + red_b - 1, :, :, ]
        HOT[ind_t[0, it], :, :] = np.abs(data_blue * mean_slop - data_red + mean_int) / (1.0 + mean_slop ** 2) ** 0.5

# for water surface
for ii in range(0, n_image):
    ind_w = np.logical_and(np.logical_and(water == 0, data[n_band * ii + nir_b - 1, :, :] < dn_max * 0.1),
                           data[n_band * ii + nir_b - 1, :, :] != background)
    num_w = np.sum(ind_w)
    if num_w > 0:
        data_nir = (data[n_band * ii + nir_b - 1, :, :])[ind_w]
        data_blue = (data[n_band * ii + blue_b - 1, :, :])[ind_w]
        rminw = max([min(data_nir), 0])
        rmaxw = rminw + maxnir_clearwater
        n_binw = 30

        ind_valid = np.logical_and(data_nir >= rminw, data_nir <= rmaxw)
        num_valid = np.sum(ind_valid)
        if num_valid > 500:
            temp = HOT[ii, :, :].copy()
            Compute_HOT = hot.Compute_hot(data_nir, data_blue, rminw, rmaxw, n_binw)
            temp[ind_w] = Compute_HOT[0]
            HOT[ii, :, :] = temp
        else:  # if all water are covered by clouds, compute HOT for land and water together
            data_blue = data[n_band * ii + blue_b - 1, :, :]
            data_red = data[n_band * ii + red_b - 1, :, :]
            HOT[ii, :, :] = abs(data_blue * mean_slop - data_red + mean_int) / (1.0 + mean_slop ** 2) ** 0.5

    # exclude background and missing gaps: these pixels marked as class 3 and HOT=0
    ind_back = data[n_band * ii + nir_b - 1, :, :] == background
    num_back = np.sum(ind_back)
    if num_back > 0:
        temp = mask[ii, :, :].copy()
        temphot = HOT[ii, :, :]
        temp[ind_back] = 3
        temphot[ind_back] = 0
        mask[ii, :, :] = temp
        HOT[ii, :, :] = temphot

print("finish cloud index calculation!")
FileName = tempfile + "\\hot_image.tif"
fp = gdal.Open(path2)
saveimage(HOT, FileName, fp, 'float')

endtime = datetime.datetime.now()
print('time used: ', (endtime - starttime).seconds, 'seconds')

# ************************* Get initial mask from K-means classification **********************
# *********************************************************************************************

# Collect samples using systematic sampling method
# convert water to a size with shadow_new
water_n = np.zeros((n_image, nl, ns)).astype(bytearray)
for ib in range(0, n_image):
    water_n[ib, :, :, ] = water.copy()

# for land surface
land_cloud_p = np.where(np.logical_and(mask != 3, water_n == 1))
land_cloud_p = np.array(land_cloud_p)
kmeansresult = classify_cloud('land', land_cloud_p, HOT, mask, water, n_image)
center_class = kmeansresult[0:2]
mask = kmeansresult[2]
Th_initial = np.zeros(2).astype(float)
Th_initial[1] = (center_class[0] + center_class[1]) / 2.0

# for water surface
water_cloud_p = np.where(np.logical_and(mask != 3, water_n == 0))
water_cloud_p = np.array(water_cloud_p)
kmeansresult = classify_cloud('water', water_cloud_p, HOT, mask, water, n_image)
center_class = kmeansresult[0:2]
mask = kmeansresult[2]
Th_initial[0] = (center_class[0] + center_class[1]) / 2.0


# remove isolate cloud pixels in initial cloud mask
mask = remove_cloud(1, mask, ns, nl, n_image)

print("finish initial cloud detection")
endtime = datetime.datetime.now()
print('time used: ', (endtime - starttime).seconds, 'seconds')
FileName = tempfile + "\\initial_cloud_mask.tif"
fp = gdal.Open(path2)
saveimage(mask, FileName, fp, 'byte')

# *************************** Detect thin cloud and remove isolate cloud pixels ***********************
# ******************************************************************************************************

# a global threshold for detect cloud in a time series with clear points<2
indc = (mask == 2)
indc_sum = np.sum(indc)
meanv = np.mean(HOT[indc])
sdv = np.std(HOT[indc])
g_th = meanv - 1.0 * sdv

# get mask for cloud pixels from HOT time-series
for i in range(0, ns):
    for j in range(0, nl):
        # judge cloud
        # only use samples<threshold to compute the mean and sd
        ind_valid = np.logical_and(mask[:, j, i] != 2, mask[:, j, i] != 3)
        num_nonc = np.sum(ind_valid)
        if num_nonc >= 2:
            b2_mean = np.mean((HOT[:, j, i])[ind_valid])
            b2_sd = np.std((HOT[:, j, i])[ind_valid])
            Th_initial_ij = Th_initial[(water[j, i]).astype(int)]
            b2_range = np.max((HOT[:, j, i])[ind_valid]) - np.min((HOT[:, j, i])[ind_valid])
            adjust_T = (Th_initial_ij - b2_range) / (Th_initial_ij + b2_range)
            # refine initial cloud
            ind_ini_cloud = np.logical_and(HOT[:, j, i] <= b2_mean + (adjust_T + A_cloud) * b2_sd, mask[:, j, i] == 2)
            num_miss_cloud = np.sum(ind_ini_cloud)

            if num_miss_cloud > 0:
                temp = mask[:, j, i].copy()
                temp[ind_ini_cloud] = 1
                mask[:, j, i] = temp

            # Add missed clouds
            ind_cloud = np.logical_and(np.logical_and(HOT[:, j, i] > b2_mean + (adjust_T + A_cloud) * b2_sd,
                                                      data[n_band * np.arange(0,
                                                                              n_image) + nir_b - 1, j, i] > dn_max * 0.1),
                                       mask[:, j, i] != 3)
            num_cloud = np.sum(ind_cloud)
            if num_cloud > 0:
                temp = mask[:, j, i].copy()
                temp[ind_cloud] = 2
                mask[:, j, i] = temp

        else:
            ind_cloud = np.logical_and(HOT[:, j, i] > g_th, mask[:, j, i] != 3)
            num_cloud = np.sum(ind_cloud)
            if num_cloud > 0:
                temp = mask[:, j, i].copy()
                temp[ind_cloud] = 2
                mask[:, j, i] = temp

# remove isolate cloud pixels by an iterative process
mask = remove_cloud(2, mask, ns, nl, n_image)

# buffer cloud by a window
mask = buffer_cloud(mask, buffer, ns, nl, n_image)

print("finish final cloud detection!")
endtime = datetime.datetime.now()
print('time used: ', (endtime - starttime).seconds, 'seconds')

# ************************* Detect shadows - Estimate potential shadows ***************************
# *************************************************************************************************

# find possible shadow area

sun = (sun / 180.0) * math.pi
longest_d = min([longest_d, ns - 1, nl - 1])

h_high = longest_d / (
            ((np.tan(sun[:, 0]) * np.sin(sun[:, 1])) ** 2 + (np.tan(sun[:, 0]) * np.cos(sun[:, 1])) ** 2) ** 0.5)
h_low = shortest_d / (
            ((np.tan(sun[:, 0]) * np.sin(sun[:, 1])) ** 2 + (np.tan(sun[:, 0]) * np.cos(sun[:, 1])) ** 2) ** 0.5)

shadow_image = np.zeros((n_image, nl, ns)).astype(bytearray)
shadow_edge = np.zeros((n_image, nl, ns)).astype(bytearray)

for ii in range(0, n_image):
    mask0 = np.zeros((nl, ns)).astype(bytearray)

    num_int = np.ceil((h_high[ii] - h_low[ii]) / 3.0)
    num_int = int(num_int)
    height = h_low[ii] + np.arange(num_int) * 3.0

    end_x1 = int(np.round(-height[num_int - 1] * np.tan(sun[ii, 0]) * np.sin(sun[ii, 1])))
    end_y1 = int(np.round(height[num_int - 1] * np.tan(sun[ii, 0]) * np.cos(sun[ii, 1])))

    # there are four cases for the shadow shifting from clouds:
    for ih in range(0, num_int):
        shift_x1 = np.round(-height[ih] * np.tan(sun[ii, 0]) * np.sin(sun[ii, 1]))
        shift_y1 = np.round(height[ih] * np.tan(sun[ii, 0]) * np.cos(sun[ii, 1]))
        shift_x1 = int(shift_x1)
        shift_y1 = int(shift_y1)
        mask_last = mask0.copy()
        if end_x1 <= 0 and end_y1 <= 0:
            mask0[0:nl + shift_y1, 0:ns + shift_x1] = mask[ii, -shift_y1:nl, -shift_x1:ns].copy()
            shadow_image[ii, :, :] = (
                np.logical_or(np.logical_or(mask0 == 2, mask_last == 2), shadow_image[ii, :, :] == 1)).astype(int)
        elif end_x1 <= 0 < end_y1:
            mask0[shift_y1:nl, 0:ns + shift_x1] = mask[ii, 0:nl - shift_y1, -shift_x1:ns].copy()
            shadow_image[ii, :, :] = (
                np.logical_or(np.logical_or(mask0 == 2, mask_last == 2), shadow_image[ii, :, :] == 1)).astype(int)
        elif end_x1 > 0 >= end_y1:
            mask0[0:nl + shift_y1, shift_x1:ns] = mask[ii, -shift_y1:nl, 0:ns - shift_x1].copy()
            shadow_image[ii, :, :] = (
                np.logical_or(np.logical_or(mask0 == 2, mask_last == 2), shadow_image[ii, :, :] == 1)).astype(int)
        elif end_x1 > 0 and end_y1 > 0:
            mask0[shift_y1:nl, shift_x1:ns] = mask[ii, 0:nl - shift_y1, 0:ns - shift_x1].copy()
            shadow_image[ii, :, :] = (
                np.logical_or(np.logical_or(mask0 == 2, mask_last == 2), shadow_image[ii, :, :] == 1)).astype(int)

    # for edge: 4 cases
    if end_x1 <= 0 and end_y1 <= 0:
        shadow_edge[ii, :, ns - 1 + end_x1:ns] = 99
        shadow_edge[ii, nl - 1 + end_y1:nl, :] = 99
    elif end_x1 <= 0 < end_y1:
        shadow_edge[ii, :, ns - 1 + end_x1:ns] = 99
        shadow_edge[ii, 0:end_y1 + 1, :] = 99
    elif end_x1 > 0 >= end_y1:
        shadow_edge[ii, :, 0:end_x1 + 1] = 99
        shadow_edge[ii, nl - 1 + end_y1:nl, :] = 99
    elif end_x1 > 0 and end_y1 > 0:
        shadow_edge[ii, :, 0:end_x1 + 1] = 99
        shadow_edge[ii, 0:end_y1 + 1, :] = 99

# overlay possible shadow to cloud mask
mask2 = mask.copy()
ind_shadow_all = np.logical_and(shadow_image == 1, mask2 == 1)
mask2[ind_shadow_all] = 0
ind_shadow_edge = np.logical_and(shadow_edge == 99, mask2 == 1)
mask2[ind_shadow_edge] = 99

# buffer possible shadow by 5*5 window
mask2 = buffer_shadow(mask2, 2, 'buffer1', 0, ns, nl, n_image)

shadow_image = 0
print("finish potential shadow location estimation!")
endtime = datetime.datetime.now()
print('time used: ', (endtime - starttime).seconds, 'seconds')
FileName = tempfile + "\\potential_shadow_zone.tif"
fp = gdal.Open(path2)
saveimage(mask2, FileName, fp, 'byte')

# **************************** Detect shadows within potential shadow zones************************
# *************************************************************************************************

# compute initial shadow index
shadow = np.zeros((n_image, nl, ns)).astype(float)

# compute the proportion of cloud in each image
p_clear_land = np.zeros(n_image)
for ii in range(0, n_image):
    ind_l = np.logical_and(np.logical_or(water == 1, data[n_band * ii + nir_b - 1, :, :] >= dn_max * 0.1),
                           mask2[ii, :, :] == 1)
    num_l = np.sum(ind_l)
    p_clear_land[ii] = num_l

# find image with least clouds
land_least_cloud = np.where((p_clear_land == max(p_clear_land)))[0]

for ii in range(0, n_image):
    ind_l = np.logical_and(np.logical_or(water == 1, data[n_band * ii + nir_b - 1, :, :] >= dn_max * 0.1),
                           mask[ii, :, :] <= 1)
    num_l = np.sum(ind_l)
    ind_comon = np.logical_and(np.logical_and(water == 1, mask2[ii, :, :] == 1), mask2[land_least_cloud, :, :] == 1)
    num_comon = np.sum(ind_comon)

    if num_comon > 100:
        xx = (data[n_band * land_least_cloud + nir_b - 1, :, :])[ind_comon]
        x1 = np.std((data[n_band * land_least_cloud + nir_b - 1, :, :])[ind_comon])
        x2 = np.std((data[n_band * ii + nir_b - 1, :, :])[ind_comon[0, :, :]])
        gain = x1 / x2
        gain1 = np.std((data[n_band * land_least_cloud + nir_b - 1, :, :])[ind_comon]) / np.std(
            (data[n_band * ii + nir_b - 1, :, :])[ind_comon[0, :, :]])
        bias1 = np.mean((data[n_band * land_least_cloud + nir_b - 1, :, :])[ind_comon]) - gain1 * np.mean(
            (data[n_band * ii + nir_b - 1, :, :])[ind_comon[0, :, :]])
        gain2 = np.std((data[n_band * land_least_cloud + swir_b - 1, :, :])[ind_comon]) / np.std(
            (data[n_band * ii + swir_b - 1, :, :])[ind_comon[0, :, :]])
        bias2 = np.mean((data[n_band * land_least_cloud + swir_b - 1, :, :])[ind_comon]) - gain2 * np.mean(
            (data[n_band * ii + swir_b - 1, :, :])[ind_comon[0, :, :]])

    else:
        gain1 = 1
        bias1 = 0
        gain2 = 1
        bias2 = 0

    # calculate shadow index for land surface
    if num_l > 0:
        data5 = (data[n_band * ii + nir_b - 1, :, :])[ind_l]
        data6 = (data[n_band * ii + swir_b - 1])[ind_l]
        data5 = gain1 * data5 + bias1
        data6 = gain2 * data6 + bias2
        temp = shadow[ii, :, :].copy()
        temp[ind_l] = data5 + data6
        shadow[ii, :, :] = temp

    # calculate shadow index for water surface
    ind_w = np.logical_and(np.logical_and(water == 0, data[n_band * ii + nir_b - 1, :, :] < dn_max * 0.1),
                           mask[ii, :, :] <= 1)
    num_w = np.sum(ind_w)
    if num_w > 0:
        data_2 = (data[n_band * ii + blue_b - 1, :, :])[ind_w]
        data_3 = (data[n_band * ii + green_b - 1, :, :])[ind_w]
        temp = shadow[ii, :, :].copy()
        temp[ind_w] = data_2 + data_3
        shadow[ii, :, :] = temp

print("finish shadow index")
endtime = datetime.datetime.now()
print('time used: ', (endtime - starttime).seconds, 'seconds')

# compute new shadow index
shadow_new = np.zeros((n_image, nl, ns)).astype(float)

# base shadow image from maximum value of the time-series
shadowbase = np.amax(shadow, axis=0)

# *******************************
# use buffer pixels as input and predict potential shadow pixels with IDW interpolator

# buffer cloud by a window
shadow_buffer = buffer_shadow(mask2, 5, 'buffer2', 10, ns, nl, n_image)
shadow_buffer = shadow_buffer.astype(int)

# predict potential shadow pixels with IDW interpolator
for ii in range(0, n_image):
    # for land surface
    shadow_new = potential_shadow('land', shadow_buffer, mask2, shadow, shadow_new, shadowbase, ii, water, col_ind,
                                  row_ind)
    # for water
    shadow_new = potential_shadow('water', shadow_buffer, mask2, shadow, shadow_new, shadowbase, ii, water, col_ind,
                                  row_ind)

FileName = tempfile + "\\IDW_shadow_darkness.tif"
fp = gdal.Open(path2)
saveimage(shadow_new, FileName, fp, 'float')
print("finish IDW shadow darkness")
endtime = datetime.datetime.now()
print('time used: ', (endtime - starttime).seconds, 'seconds')

# detect shadow from the shadow index
# Step 1 get initial mask from K-means classification
mask_shadow_ini = mask.copy()
# collect samples using systematic sampling method

# for land surface
land_shadow_p = np.where(np.logical_and(shadow_new < 0, water_n == 1))
land_shadow_p = np.array(land_shadow_p)
kmeansresult = classify_shadow('land', land_shadow_p, shadow_new, mask_shadow_ini, water, n_image)
mask_shadow_ini = kmeansresult[2]

# for water surface
water_shadow_p = np.where(np.logical_and(shadow_new < 0, water_n == 0))
water_shadow_p = np.array(water_shadow_p)
kmeansresult = classify_shadow('water', water_shadow_p, shadow_new, mask_shadow_ini, water, n_image)
mask_shadow_ini = kmeansresult[2]

print("finish initial shadow detection")
endtime = datetime.datetime.now()
print('time used: ', (endtime - starttime).seconds, 'seconds')

# refine mask for shadow pixels from shadow time-series
for i in range(0, ns):
    for j in range(0, nl):

        # only use non_initial_shadow points to compute the mean and sd
        ind_valid = mask_shadow_ini[:, j, i] == 1
        num_nonc = np.sum(ind_valid)
        if num_nonc >= 2:
            sample = (shadow[:, j, i])[ind_valid]
            b2_mean = np.mean(sample)
            b2_sd = np.std(sample)
            # refine initial shadow
            ind_shadow = np.logical_and(shadow[:, j, i] < b2_mean, mask_shadow_ini[:, j, i] == 0)
            num_shadow = np.sum(ind_shadow)  # consider edge pixels

            if num_shadow > 0:
                temp = mask[:, j, i].copy()
                temp[ind_shadow] = 0
                mask[:, j, i] = temp
            else:
                continue

            # Add shadow from non-initial window
            ind_shadow = np.logical_and(np.logical_and(shadow[:, j, i] < (b2_mean - B_shadow * b2_sd),
                                                       shadow[:, j, i] < dn_max * 0.5), mask2[:, j, i] == 0)
            num_shadow = np.sum(ind_shadow)
            if num_shadow > 0:
                temp = mask[:, j, i].copy()
                temp[ind_shadow] = 0
                mask[:, j, i] = temp
            else:
                continue

            # for edge pixels, edge pixels using less strict threshold
            ind_shadow_edge = np.logical_and(np.logical_and(shadow[:, j, i] < (b2_mean - (B_shadow + 1.0) * b2_sd),
                                                            shadow[:, j, i] < dn_max * 0.5), mask2[:, j, i] == 99)
            num_shadow = np.sum(ind_shadow_edge)
            if num_shadow > 0:
                temp = mask[:, j, i].copy()
                temp[ind_shadow_edge] = 0
                mask[:, j, i] = temp
            else:
                continue

        else:
            mask[:, j, i] = mask_shadow_ini[:, j, i].copy()

print("finish final shadow detection!")
endtime = datetime.datetime.now()
print('time used: ', (endtime - starttime).seconds, 'seconds')

mask_shadow_ini = 0

# correct isolated shadow
mask = remove_shadow(mask, ns, nl, n_image)
# buffer shadow by moving window
shadow1 = buffer_shadow(mask, 1, 'buffer3', 0, ns, nl, n_image)
mask = shadow1.copy()

print("Obtain the final cloud and shadow mask!")
endtime = datetime.datetime.now()
print('time used: ', (endtime - starttime).seconds, 'seconds')
# output the results
path_output = tempfile
FileName = path_output + "\\cloud_mask_ATSA.tif"
fp = gdal.Open(path2)
saveimage(mask, FileName, fp, 'int')
